module.exports = {
  MONGO_URI:       'mongodb+srv://s1r9d11drive1:xMkoF5xHceNNNia9@mujdrive.kmz2jmj.mongodb.net/?retryWrites=true&w=majority&appName=mujdrive',
  DB_NAME:         'Users',
  JWT_SECRET:      'mujtpc',
  JWT_EXPIRES_IN:  '30d',
  OTP_EXPIRES_MIN: 10      // OTP lifetime in minutes
};
