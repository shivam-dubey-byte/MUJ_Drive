// config/config.js

module.exports = {
  JWT_SECRET: 'mujtpc',
  MONGO_URI:  'mongodb+srv://s1r9d11drive1:xMkoF5xHceNNNia9@mujdrive.kmz2jmj.mongodb.net/?retryWrites=true&w=majority&appName=mujdrive',
  DB_NAME:    'rides'                // ← add this
};
